﻿#include "Fonts.h"
#include <Windows.h>
#include <cstdio>

#include "Fonts/IconsFontAwesome6Pro.h"
#include "Fonts/Logo_Fonts.h"

namespace GetFont {
    ImFont* font_logo = nullptr;
    ImFont* font_msyh = nullptr;
}

void SetupFonts() {
    ImGuiIO& io = ImGui::GetIO();
    
    GetFont::font_msyh = io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\msyh.ttc", 16.0f, nullptr, nullptr);
    if (!GetFont::font_msyh) {
        printf("(>_<) ImGui: Fonts Init: g_font_msyh");
        GetFont::font_msyh = io.Fonts->AddFontDefault();
    }
    static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.GlyphOffset = { 0.f, 1.f };
    io.Fonts->AddFontFromFileTTF("C:\\Neverlose\\Fonts\\Font Awesome 6 Pro-Regular-400.otf", 13.0f, &icons_config, icons_ranges);

    GetFont::font_logo = io.Fonts->AddFontFromMemoryTTF(museo900_binary, sizeof museo900_binary);
}
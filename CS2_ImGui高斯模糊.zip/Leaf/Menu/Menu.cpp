﻿#include "Menu.h"
#include "Blur.h"
#include "../additionals/ImGui/imgui.h"
#include "../additionals/ImGui/imgui_internal.h"
#include "Fonts.h"

namespace{

    constexpr float kWindowRounding = 6.9f;
    ImColor g_bgTint = ImColor(5, 5, 8, 240);

    void DrawBlurBackground(ID3D11ShaderResourceView* blurTexture)
    {
        const ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        if (displaySize.x <= 0.0f || displaySize.y <= 0.0f)
            return;

        const ImVec2 windowPosition = ImGui::GetWindowPos();
        const ImVec2 windowSize = ImGui::GetWindowSize();
        const ImVec2 windowEnd(windowPosition.x + windowSize.x, windowPosition.y + windowSize.y);

        const ImVec2 uvMin(windowPosition.x / displaySize.x, windowPosition.y / displaySize.y);
        const ImVec2 uvMax(windowEnd.x / displaySize.x, windowEnd.y / displaySize.y);

        ImDrawList* drawList = ImGui::GetWindowDrawList();

        drawList->PushClipRect(windowPosition, windowEnd, false);

        //模糊底图
        drawList->AddImageRounded(
            reinterpret_cast<ImTextureID>(blurTexture),
            windowPosition, windowEnd,
            uvMin, uvMax,
            IM_COL32(255, 255, 255, 255),
            kWindowRounding,
            ImDrawFlags_RoundCornersAll);

        //染色层（顺序在模糊之后 = 叠在模糊上面）
        drawList->AddRectFilled(
            windowPosition, windowEnd,
            g_bgTint,
            kWindowRounding,
            ImDrawFlags_RoundCornersAll);

        drawList->PopClipRect();
    }
}

void Tab_Logo(ImDrawList* draw, ImFont* font, float font_size, ImVec2 pos, ImU32 accent_color, ImU32 text_color)
{
    if (!font) return;

    constexpr float width = 170.0f;
    constexpr float offset_y = 20.0f;
    const char* text = "NEVERLOSE";

    const float text_width = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text).x;
    const float center_x = pos.x + width * 0.5f - text_width * 0.5f;

    // 阴影（accent_color）
    draw->AddText(font, font_size, ImVec2(center_x + 1.0f, pos.y + offset_y), accent_color, text);

    // 主文字
    draw->AddText(font, font_size, ImVec2(center_x, pos.y + offset_y), text_color, text);
}

void menu() {
	bool BeginOpen = true;
	ImGuiWindowFlags Beginflags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings;

	ImGui::SetNextWindowSize(ImVec2(830, 580));

	// 模糊就绪时窗口背景完全透明，由模糊图充当背景；
	ID3D11ShaderResourceView* blurTexture = Blur::GetBlurTexture();
	const bool hasBlur = (blurTexture != nullptr);
	const ImVec4 windowBackground = hasBlur ? ImVec4(0.0f, 0.0f, 0.0f, 0.0f) : ImVec4(0.06f, 0.06f, 0.08f, 0.94f);
	ImGui::PushStyleColor(ImGuiCol_WindowBg, windowBackground);
	ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, kWindowRounding);
	ImGui::Begin("Menu", &BeginOpen ,Beginflags);

    auto window = ImGui::GetCurrentWindow();
    auto draw = window->DrawList;
    auto pos = window->Pos;
    auto size = window->Size;

    if (hasBlur) {
        DrawBlurBackground(blurTexture);
    }
		

    Tab_Logo(draw, GetFont::font_logo, 28.0f, pos, ImColor(255,255,255), ImColor(255, 255, 255));

	ImGui::SetCursorPos(ImVec2(24.0f, 52.0f));
	ImGui::SetNextItemWidth(260.0f);
	ImGui::SliderFloat("模糊半径", &Blur::Radius, Blur::kMinRadius, Blur::kMaxRadius, "%.0f px");
    ImGui::SetCursorPos(ImVec2(24.0f, 92.0f));
    ImGui::SetNextItemWidth(260.0f);
    ImGui::ColorEdit4("背景染色", (float*)&g_bgTint,
        ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_AlphaPreviewHalf);

	ImGui::End();
	ImGui::PopStyleVar();
	ImGui::PopStyleColor();
}

﻿#include <Windows.h>
#include "Blur.h"
#include <d3dcompiler.h>
#include <cstring>

#pragma comment(lib, "d3dcompiler.lib")

namespace Blur
{
    // 默认模糊半径（纹素），可在菜单中通过滑动条实时调节
    float Radius = 15.0f;

    namespace
    {
        // --------------------------------------------------------------------
        //  着色器源码
        //  VS 用 SV_VertexID 生成覆盖全屏的三角形，因此无需顶点缓冲；
        //  PS 执行一维高斯卷积，采样间隔固定为 1 个纹素，方向由常量缓冲指定。
        // --------------------------------------------------------------------
        const char* const kVertexShaderSource = R"HLSL(
            struct VSOutput
            {
                float4 Position : SV_POSITION;
                float2 UV       : TEXCOORD0;
            };

            VSOutput VSMain(uint vertexId : SV_VertexID)
            {
                VSOutput output;
                float2 uv = float2((vertexId << 1) & 2, vertexId & 2);
                output.Position = float4(uv * float2(2.0f, -2.0f) + float2(-1.0f, 1.0f), 0.0f, 1.0f);
                output.UV       = uv;
                return output;
            }
        )HLSL";

        const char* const kPixelShaderSource = R"HLSL(
            Texture2D    InputTexture : register(t0);
            SamplerState InputSampler : register(s0);

            cbuffer BlurConstants : register(b0)
            {
                float2 BlurDirection;   // (1,0) 水平卷积；(0,1) 垂直卷积
                float  PixelSize;       // 相邻纹素的 UV 间距
                float  Radius;          // 高斯核半径（纹素）
            };

            float4 PSMain(float4 position : SV_Position, float2 uv : TEXCOORD0) : SV_Target
            {
                float radius = clamp(Radius, 0.0f, 64.0f);
                if (radius < 0.5f)
                    return InputTexture.Sample(InputSampler, uv);

                // 核半径取 3 sigma，可覆盖约 99.7% 的高斯权重
                float sigma = radius / 3.0f;

                float4 accumulated = float4(0.0f, 0.0f, 0.0f, 0.0f);
                float  weightSum   = 0.0f;

                [loop]
                for (float offset = -radius; offset <= radius; offset += 1.0f)
                {
                    float weight = exp(-(offset * offset) / (2.0f * sigma * sigma));
                    accumulated += InputTexture.Sample(InputSampler, uv + BlurDirection * (offset * PixelSize)) * weight;
                    weightSum   += weight;
                }

                // alpha 固定为 1：后台缓冲的 alpha 通道可能为 0，
                // 原样输出会被 ImGui 的 Alpha 混合判定为全透明。
                return float4(accumulated.rgb / weightSum, 1.0f);
            }
        )HLSL";

        // 与 HLSL 中的 BlurConstants 一一对应（16 字节）
        struct BlurConstants
        {
            float direction[2];
            float pixelSize;
            float radius;
        };
        static_assert(sizeof(BlurConstants) == 16, "常量缓冲大小必须是 16 字节");

        // ---- D3D 设备与管线对象 ----
        ID3D11Device*            g_device         = nullptr;
        ID3D11DeviceContext*     g_context        = nullptr;
        ID3D11VertexShader*      g_vertexShader   = nullptr;
        ID3D11PixelShader*       g_pixelShader    = nullptr;
        ID3D11Buffer*            g_constantBuffer = nullptr;
        ID3D11SamplerState*      g_sampler        = nullptr;
        ID3D11RasterizerState*   g_rasterizer     = nullptr;
        ID3D11BlendState*        g_blendState     = nullptr;
        ID3D11DepthStencilState* g_depthStencil   = nullptr;

        // ---- 卷积用的纹理（与后台缓冲同尺寸、同格式） ----
        ID3D11Texture2D*          g_horizontalTexture = nullptr;  // 水平卷积结果
        ID3D11RenderTargetView*   g_horizontalTarget  = nullptr;
        ID3D11ShaderResourceView* g_horizontalView    = nullptr;
        ID3D11Texture2D*          g_verticalTexture   = nullptr;  // 垂直卷积结果（最终输出）
        ID3D11RenderTargetView*   g_verticalTarget    = nullptr;
        ID3D11ShaderResourceView* g_verticalView      = nullptr;

        // 回退路径专用：部分驱动不允许直接为交换链后备缓冲创建 SRV
        ID3D11Texture2D*          g_captureTexture = nullptr;
        ID3D11ShaderResourceView* g_captureView    = nullptr;

        // ---- 当前纹理尺寸与格式 ----
        UINT        g_width  = 0;
        UINT        g_height = 0;
        DXGI_FORMAT g_format = DXGI_FORMAT_UNKNOWN;

        // 本帧是否已产出可用的模糊结果
        bool g_hasResult = false;

        // 统一释放 COM 资源并将其置空
        template <typename T>
        void ReleaseResource(T*& resource)
        {
            if (resource != nullptr)
            {
                resource->Release();
                resource = nullptr;
            }
        }

        // 去掉 sRGB 后缀：避免采样时被硬件自动做 gamma 解码，导致画面偏色
        DXGI_FORMAT NormalizeFormat(DXGI_FORMAT format)
        {
            switch (format)
            {
            case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return DXGI_FORMAT_R8G8B8A8_UNORM;
            case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return DXGI_FORMAT_B8G8R8A8_UNORM;
            default:                              return format;
            }
        }

        // 释放全部纹理资源并复位尺寸信息
        void ReleaseTextureResources()
        {
            ReleaseResource(g_horizontalView);
            ReleaseResource(g_horizontalTarget);
            ReleaseResource(g_horizontalTexture);
            ReleaseResource(g_verticalView);
            ReleaseResource(g_verticalTarget);
            ReleaseResource(g_verticalTexture);
            ReleaseResource(g_captureView);
            ReleaseResource(g_captureTexture);

            g_width  = 0;
            g_height = 0;
            g_format = DXGI_FORMAT_UNKNOWN;
        }

        // 按后台缓冲的尺寸与格式创建（或重建）纹理资源
        bool CreateTextureResources(UINT width, UINT height, DXGI_FORMAT format)
        {
            ReleaseTextureResources();

            if (width == 0 || height == 0)
                return false;

            // 创建过程中任意一步失败，都回滚到未初始化状态，便于下一帧重试
            const auto fail = []() -> bool
            {
                ReleaseTextureResources();
                return false;
            };

            g_width  = width;
            g_height = height;
            g_format = format;

            D3D11_TEXTURE2D_DESC textureDesc = {};
            textureDesc.Width            = width;
            textureDesc.Height           = height;
            textureDesc.MipLevels        = 1;
            textureDesc.ArraySize        = 1;
            textureDesc.Format           = format;
            textureDesc.SampleDesc.Count = 1;
            textureDesc.Usage            = D3D11_USAGE_DEFAULT;
            textureDesc.BindFlags        = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;

            if (FAILED(g_device->CreateTexture2D(&textureDesc, nullptr, &g_horizontalTexture)))
                return fail();
            if (FAILED(g_device->CreateRenderTargetView(g_horizontalTexture, nullptr, &g_horizontalTarget)))
                return fail();
            if (FAILED(g_device->CreateShaderResourceView(g_horizontalTexture, nullptr, &g_horizontalView)))
                return fail();

            if (FAILED(g_device->CreateTexture2D(&textureDesc, nullptr, &g_verticalTexture)))
                return fail();
            if (FAILED(g_device->CreateRenderTargetView(g_verticalTexture, nullptr, &g_verticalTarget)))
                return fail();
            if (FAILED(g_device->CreateShaderResourceView(g_verticalTexture, nullptr, &g_verticalView)))
                return fail();

            // 回退路径用的拷贝纹理：仅作为着色器输入
            D3D11_TEXTURE2D_DESC captureDesc = textureDesc;
            captureDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
            if (FAILED(g_device->CreateTexture2D(&captureDesc, nullptr, &g_captureTexture)))
                return fail();
            if (FAILED(g_device->CreateShaderResourceView(g_captureTexture, nullptr, &g_captureView)))
                return fail();

            return true;
        }

        // 更新常量缓冲中的卷积参数
        bool UpdateConstants(float directionX, float directionY, float pixelSize)
        {
            D3D11_MAPPED_SUBRESOURCE mapped = {};
            if (FAILED(g_context->Map(g_constantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped)))
                return false;

            BlurConstants constants = {};
            constants.direction[0] = directionX;
            constants.direction[1] = directionY;
            constants.pixelSize    = pixelSize;
            constants.radius       = Radius;

            std::memcpy(mapped.pData, &constants, sizeof(BlurConstants));
            g_context->Unmap(g_constantBuffer, 0);
            return true;
        }

        //  管线状态守卫
        class PipelineStateGuard
        {
        public:
            explicit PipelineStateGuard(ID3D11DeviceContext* context)
                : m_context(context)
            {
                m_context->OMGetRenderTargets(1, &m_renderTarget, &m_depthStencil);
                m_context->OMGetBlendState(&m_blendState, m_blendFactor, &m_sampleMask);
                m_context->OMGetDepthStencilState(&m_depthStencilState, &m_stencilRef);
                m_context->PSGetShaderResources(0, 1, &m_pixelResource);
                m_context->PSGetShader(&m_pixelShader, nullptr, nullptr);
                m_context->VSGetShader(&m_vertexShader, nullptr, nullptr);
                m_context->PSGetConstantBuffers(0, 1, &m_pixelConstantBuffer);
                m_context->PSGetSamplers(0, 1, &m_pixelSampler);
                m_context->RSGetState(&m_rasterizer);
                m_context->IAGetInputLayout(&m_inputLayout);
                m_context->IAGetPrimitiveTopology(&m_topology);

                m_viewportCount = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
                m_context->RSGetViewports(&m_viewportCount, m_viewports);

                m_scissorCount = 0;
                m_context->RSGetScissorRects(&m_scissorCount, nullptr);
                if (m_scissorCount > 0)
                {
                    m_scissorCount = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
                    m_context->RSGetScissorRects(&m_scissorCount, m_scissorRects);
                }
            }

            ~PipelineStateGuard()
            {
                m_context->OMSetRenderTargets(1, &m_renderTarget, m_depthStencil);
                m_context->OMSetBlendState(m_blendState, m_blendFactor, m_sampleMask);
                m_context->OMSetDepthStencilState(m_depthStencilState, m_stencilRef);
                m_context->PSSetShaderResources(0, 1, &m_pixelResource);
                m_context->PSSetShader(m_pixelShader, nullptr, 0);
                m_context->VSSetShader(m_vertexShader, nullptr, 0);
                m_context->PSSetConstantBuffers(0, 1, &m_pixelConstantBuffer);
                m_context->PSSetSamplers(0, 1, &m_pixelSampler);
                m_context->RSSetState(m_rasterizer);
                m_context->IASetInputLayout(m_inputLayout);
                m_context->IASetPrimitiveTopology(m_topology);
                m_context->RSSetViewports(m_viewportCount, m_viewports);
                if (m_scissorCount > 0)
                    m_context->RSSetScissorRects(m_scissorCount, m_scissorRects);

                ReleaseResource(m_renderTarget);
                ReleaseResource(m_depthStencil);
                ReleaseResource(m_blendState);
                ReleaseResource(m_depthStencilState);
                ReleaseResource(m_pixelResource);
                ReleaseResource(m_pixelShader);
                ReleaseResource(m_vertexShader);
                ReleaseResource(m_pixelConstantBuffer);
                ReleaseResource(m_pixelSampler);
                ReleaseResource(m_rasterizer);
                ReleaseResource(m_inputLayout);
            }

            PipelineStateGuard(const PipelineStateGuard&)            = delete;
            PipelineStateGuard& operator=(const PipelineStateGuard&) = delete;

        private:
            ID3D11DeviceContext*      m_context             = nullptr;
            ID3D11RenderTargetView*   m_renderTarget        = nullptr;
            ID3D11DepthStencilView*   m_depthStencil        = nullptr;
            ID3D11BlendState*         m_blendState          = nullptr;
            FLOAT                     m_blendFactor[4]      = {};
            UINT                      m_sampleMask          = 0;
            ID3D11DepthStencilState*  m_depthStencilState   = nullptr;
            UINT                      m_stencilRef          = 0;
            ID3D11ShaderResourceView* m_pixelResource       = nullptr;
            ID3D11PixelShader*        m_pixelShader         = nullptr;
            ID3D11VertexShader*       m_vertexShader        = nullptr;
            ID3D11Buffer*             m_pixelConstantBuffer = nullptr;
            ID3D11SamplerState*       m_pixelSampler        = nullptr;
            ID3D11RasterizerState*    m_rasterizer          = nullptr;
            ID3D11InputLayout*        m_inputLayout         = nullptr;
            D3D11_PRIMITIVE_TOPOLOGY  m_topology            = D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED;
            UINT                      m_viewportCount       = 0;
            D3D11_VIEWPORT            m_viewports[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE] = {};
            UINT                      m_scissorCount        = 0;
            D3D11_RECT                m_scissorRects[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE] = {};
        };

        // 编译指定入口的着色器字节码
        bool CompileShader(const char* source, const char* entryPoint, const char* target, ID3DBlob** outByteCode)
        {
            ID3DBlob* errorBlob = nullptr;
            const HRESULT result = D3DCompile(
                source, std::strlen(source), "BlurShader",
                nullptr, nullptr, entryPoint, target,
                D3DCOMPILE_ENABLE_STRICTNESS | D3DCOMPILE_OPTIMIZATION_LEVEL3, 0,
                outByteCode, &errorBlob);

            if (FAILED(result))
            {
                if (errorBlob != nullptr)
                {
                    OutputDebugStringA(static_cast<const char*>(errorBlob->GetBufferPointer()));
                    errorBlob->Release();
                }
                return false;
            }

            if (errorBlob != nullptr)
                errorBlob->Release();

            return true;
        }

        // 执行水平 + 垂直两趟一维高斯卷积
        void ExecuteBlurPass(ID3D11ShaderResourceView* sourceView)
        {
            PipelineStateGuard stateGuard(g_context);

            D3D11_VIEWPORT viewport = {};
            viewport.TopLeftX = 0.0f;
            viewport.TopLeftY = 0.0f;
            viewport.Width    = static_cast<float>(g_width);
            viewport.Height   = static_cast<float>(g_height);
            viewport.MinDepth = 0.0f;
            viewport.MaxDepth = 1.0f;

            ID3D11ShaderResourceView* nullView = nullptr;

            g_context->IASetInputLayout(nullptr);       // 顶点由 SV_VertexID 生成，无需输入布局
            g_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            g_context->VSSetShader(g_vertexShader, nullptr, 0);
            g_context->PSSetShader(g_pixelShader, nullptr, 0);
            g_context->PSSetConstantBuffers(0, 1, &g_constantBuffer);
            g_context->PSSetSamplers(0, 1, &g_sampler);
            g_context->RSSetState(g_rasterizer);
            g_context->RSSetViewports(1, &viewport);
            g_context->OMSetBlendState(g_blendState, nullptr, 0xFFFFFFFF);
            g_context->OMSetDepthStencilState(g_depthStencil, 0);

            //水平卷积（PixelSize 取横向纹素间距）
            if (!UpdateConstants(1.0f, 0.0f, 1.0f / static_cast<float>(g_width)))
                return;

            g_context->OMSetRenderTargets(1, &g_horizontalTarget, nullptr);
            g_context->PSSetShaderResources(0, 1, &sourceView);
            g_context->Draw(3, 0);
            g_context->PSSetShaderResources(0, 1, &nullView);

            //垂直卷积（PixelSize 取纵向纹素间距）
            if (!UpdateConstants(0.0f, 1.0f, 1.0f / static_cast<float>(g_height)))
                return;

            g_context->OMSetRenderTargets(1, &g_verticalTarget, nullptr);
            g_context->PSSetShaderResources(0, 1, &g_horizontalView);
            g_context->Draw(3, 0);
            g_context->PSSetShaderResources(0, 1, &nullView);

            g_hasResult = true;
        }

        // 取得本帧可用于采样的源视图
        ID3D11ShaderResourceView* AcquireSourceView(ID3D11Texture2D* backBuffer, DXGI_FORMAT backBufferFormat)
        {
            D3D11_SHADER_RESOURCE_VIEW_DESC viewDesc = {};
            viewDesc.Format                    = g_format;
            viewDesc.ViewDimension             = D3D11_SRV_DIMENSION_TEXTURE2D;
            viewDesc.Texture2D.MostDetailedMip = 0;
            viewDesc.Texture2D.MipLevels       = 1;

            ID3D11ShaderResourceView* directView = nullptr;
            HRESULT result = g_device->CreateShaderResourceView(backBuffer, &viewDesc, &directView);

            if (FAILED(result))
            {
                viewDesc.Format = backBufferFormat;     // 回退到原始格式再试一次
                result = g_device->CreateShaderResourceView(backBuffer, &viewDesc, &directView);
            }

            if (SUCCEEDED(result) && directView != nullptr)
                return directView;                      // 由调用方负责释放

            g_context->CopyResource(g_captureTexture, backBuffer);
            return nullptr;                             // 调用方改用 g_captureView
        }
    }

    bool Initialize(ID3D11Device* device, ID3D11DeviceContext* context)
    {
        if (g_device != nullptr)
            return true;                            // 已初始化，避免重复创建资源

        if (device == nullptr || context == nullptr)
            return false;

        g_device  = device;
        g_context = context;

        //编译并创建顶点着色器
        ID3DBlob* vertexByteCode = nullptr;
        if (!CompileShader(kVertexShaderSource, "VSMain", "vs_5_0", &vertexByteCode))
        {
            Shutdown();
            return false;
        }
        const HRESULT vertexResult = g_device->CreateVertexShader(
            vertexByteCode->GetBufferPointer(), vertexByteCode->GetBufferSize(), nullptr, &g_vertexShader);
        vertexByteCode->Release();
        if (FAILED(vertexResult))
        {
            Shutdown();
            return false;
        }

        //编译并创建像素着色器
        ID3DBlob* pixelByteCode = nullptr;
        if (!CompileShader(kPixelShaderSource, "PSMain", "ps_5_0", &pixelByteCode))
        {
            Shutdown();
            return false;
        }
        const HRESULT pixelResult = g_device->CreatePixelShader(
            pixelByteCode->GetBufferPointer(), pixelByteCode->GetBufferSize(), nullptr, &g_pixelShader);
        pixelByteCode->Release();
        if (FAILED(pixelResult))
        {
            Shutdown();
            return false;
        }

        //常量缓冲
        D3D11_BUFFER_DESC constantDesc = {};
        constantDesc.ByteWidth      = sizeof(BlurConstants);
        constantDesc.Usage          = D3D11_USAGE_DYNAMIC;
        constantDesc.BindFlags      = D3D11_BIND_CONSTANT_BUFFER;
        constantDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        if (FAILED(g_device->CreateBuffer(&constantDesc, nullptr, &g_constantBuffer)))
        {
            Shutdown();
            return false;
        }

        // ---- 采样器：双线性 + 边缘钳制，避免边界采到对侧像素 ----
        D3D11_SAMPLER_DESC samplerDesc = {};
        samplerDesc.Filter         = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
        samplerDesc.AddressU       = D3D11_TEXTURE_ADDRESS_CLAMP;
        samplerDesc.AddressV       = D3D11_TEXTURE_ADDRESS_CLAMP;
        samplerDesc.AddressW       = D3D11_TEXTURE_ADDRESS_CLAMP;
        samplerDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
        samplerDesc.MinLOD         = 0.0f;
        samplerDesc.MaxLOD         = D3D11_FLOAT32_MAX;
        if (FAILED(g_device->CreateSamplerState(&samplerDesc, &g_sampler)))
        {
            Shutdown();
            return false;
        }

        // ---- 光栅化状态：全屏三角形无需背面剔除 ----
        D3D11_RASTERIZER_DESC rasterizerDesc = {};
        rasterizerDesc.FillMode        = D3D11_FILL_SOLID;
        rasterizerDesc.CullMode        = D3D11_CULL_NONE;
        rasterizerDesc.DepthClipEnable = TRUE;
        rasterizerDesc.ScissorEnable   = FALSE;
        if (FAILED(g_device->CreateRasterizerState(&rasterizerDesc, &g_rasterizer)))
        {
            Shutdown();
            return false;
        }

        // ---- 混合状态：直接覆盖写，不做混合 ----
        D3D11_BLEND_DESC blendDesc = {};
        blendDesc.RenderTarget[0].BlendEnable           = FALSE;
        blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
        if (FAILED(g_device->CreateBlendState(&blendDesc, &g_blendState)))
        {
            Shutdown();
            return false;
        }

        // ---- 深度模板状态：关闭深度测试与写入 ----
        D3D11_DEPTH_STENCIL_DESC depthDesc = {};
        depthDesc.DepthEnable    = FALSE;
        depthDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
        depthDesc.DepthFunc      = D3D11_COMPARISON_ALWAYS;
        if (FAILED(g_device->CreateDepthStencilState(&depthDesc, &g_depthStencil)))
        {
            Shutdown();
            return false;
        }

        return true;
    }

    void Shutdown()
    {
        ReleaseTextureResources();

        ReleaseResource(g_depthStencil);
        ReleaseResource(g_blendState);
        ReleaseResource(g_rasterizer);
        ReleaseResource(g_sampler);
        ReleaseResource(g_constantBuffer);
        ReleaseResource(g_pixelShader);
        ReleaseResource(g_vertexShader);

        // g_device / g_context 由调用方持有，此处仅解除引用
        g_device    = nullptr;
        g_context   = nullptr;
        g_hasResult = false;
    }

    void ProcessFrame(IDXGISwapChain* swapChain)
    {
        g_hasResult = false;

        if (g_device == nullptr || g_context == nullptr || swapChain == nullptr)
            return;

        if (Radius < 0.5f)
            return;                                 // 半径过小时不做任何处理

        // ---- 1. 获取后台缓冲 ----
        ID3D11Texture2D* backBuffer = nullptr;
        if (FAILED(swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer))) || backBuffer == nullptr)
            return;

        D3D11_TEXTURE2D_DESC backBufferDesc = {};
        backBuffer->GetDesc(&backBufferDesc);

        // ---- 2. 分辨率或格式变化时重建纹理资源 ----
        const DXGI_FORMAT sourceFormat = NormalizeFormat(backBufferDesc.Format);
        if (backBufferDesc.Width  != g_width ||
            backBufferDesc.Height != g_height ||
            sourceFormat          != g_format)
        {
            if (!CreateTextureResources(backBufferDesc.Width, backBufferDesc.Height, sourceFormat))
            {
                backBuffer->Release();
                return;
            }
        }

        // ---- 3. 取得可采样的源视图 ----
        ID3D11ShaderResourceView* sourceView = AcquireSourceView(backBuffer, backBufferDesc.Format);
        backBuffer->Release();

        if (sourceView == nullptr)
            sourceView = g_captureView;             // 走拷贝回退路径

        if (sourceView == nullptr)
            return;

        // ---- 4. 两趟分离高斯卷积 ----
        ExecuteBlurPass(sourceView);

        // 直接创建的视图需要本帧释放；回退路径的视图由纹理持有，不能释放
        if (sourceView != g_captureView)
            sourceView->Release();
    }

    ID3D11ShaderResourceView* GetBlurTexture()
    {
        if (!g_hasResult)
            return nullptr;

        return g_verticalView;
    }
}

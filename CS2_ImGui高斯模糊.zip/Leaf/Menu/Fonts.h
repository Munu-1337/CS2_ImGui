﻿#pragma once
#include "../additionals/ImGui/imgui.h"

namespace GetFont {
    extern ImFont* font_logo;
    extern ImFont* font_msyh;
}
void SetupFonts();


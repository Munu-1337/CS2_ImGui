﻿#pragma once
#include <d3d11.h>
#include <dxgi.h>

// ============================================================================
//  Blur —— 菜单背景高斯模糊模块
//
//  实现思路：在每帧 Present 之前取后台缓冲，依次执行「水平」与「垂直」
//  两趟一维高斯卷积，得到一张模糊纹理，供菜单窗口作为「磨砂玻璃」背景绘制。
//  卷积采样间隔固定为 1 个纹素，核半径 = Radius，标准差 sigma = Radius / 3，
//  可覆盖约 99.7% 的高斯权重。
// ============================================================================
namespace Blur
{
    // 高斯核半径（单位：纹素）；< 0.5 时跳过模糊处理
    // 直接绑定到菜单中的滑动条
    extern float Radius;

    // 滑动条可调范围
    constexpr float kMinRadius = 0.0f;
    constexpr float kMaxRadius = 32.0f;

    // 初始化模糊管线（须在 D3D11 设备创建完成之后调用）
    // device  —— Present Hook 中获取到的 D3D11 设备
    // context —— 对应的立即上下文
    // 返回 true 表示着色器与管线状态创建成功
    bool Initialize(ID3D11Device* device, ID3D11DeviceContext* context);

    // 释放全部 D3D 资源
    void Shutdown();

    // 每帧调用：捕获后台缓冲并执行高斯模糊
    // swapChain —— 当前 Present 的后台交换链
    void ProcessFrame(IDXGISwapChain* swapChain);

    // 获取模糊结果纹理；本帧模糊未执行或失败时返回 nullptr
    ID3D11ShaderResourceView* GetBlurTexture();
}

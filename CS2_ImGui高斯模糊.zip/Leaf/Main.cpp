﻿#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include "additionals/ImGui/imgui.h"
#include "additionals/ImGui/imgui_impl_win32.h"
#include "additionals/ImGui/imgui_impl_dx11.h"
#include "additionals/ImGui/imgui_internal.h"
#include "additionals/MinHook/include/MinHook.h"
#include "PatternScan.hpp"
#include "Menu/Menu.h"
#include "Menu/Blur.h"
#include "Menu/Fonts.h"

void SetupImGuiD3D11(HWND Window, ID3D11Device* device, ID3D11DeviceContext* device_context) {
    ImGui::CreateContext();
    ImGui_ImplWin32_Init(Window);
    ImGui_ImplDX11_Init(device, device_context);
    SetupFonts();
}
using DXGIPresentFn = HRESULT(__stdcall*)(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);
using DXGIResizeBuffersFn = HRESULT(__stdcall*)(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT Format, UINT SwapChainFlags);
DXGIPresentFn OriginalPresent;
DXGIResizeBuffersFn OriginalResizeBuffers;
static ID3D11DeviceContext* context;
static ID3D11RenderTargetView* renderTargetView;
static ID3D11Device* device;
static DXGI_SWAP_CHAIN_DESC desc;
static WNDPROC OrignalWndProc;
extern IMGUI_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND Window, UINT Msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc(HWND Window, UINT Msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(Window, Msg, wParam, lParam)) return 1L;
    return CallWindowProc(OrignalWndProc, Window, Msg, wParam, lParam);
}
HRESULT __stdcall HookedPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags) {
    static auto bMakeOnce = [pSwapChain]()->bool {
        pSwapChain->GetDesc(&desc);
        pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&device);
        device->GetImmediateContext(&context);
        ID3D11Texture2D* pBackBuffer{};
        pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
        device->CreateRenderTargetView(pBackBuffer, nullptr, &renderTargetView);
        pBackBuffer->Release();
        SetupImGuiD3D11(desc.OutputWindow, device, context);
        Blur::Initialize(device, context);
        OrignalWndProc = (WNDPROC)SetWindowLongPtrA(desc.OutputWindow, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(&WndProc));
        return true;
        };
    static bool make = bMakeOnce();
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    Blur::ProcessFrame(pSwapChain);

    menu();

    ImGui::Render();
    context->OMSetRenderTargets(1, &renderTargetView, NULL);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    return OriginalPresent(pSwapChain, SyncInterval, Flags);
}
void Setup() {
    MH_Initialize();
    void* pPresent = PatternScan("Gameoverlayrenderer64.dll", "48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 83 EC ? 41 8B F0");

    printf("[+] Present = %p", pPresent);

    MH_CreateHook(pPresent, &HookedPresent, reinterpret_cast<void**>(&OriginalPresent));
    MH_EnableHook(MH_ALL_HOOKS);
}
BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
#ifdef _DEBUG
        AllocConsole();
        FILE* f;
        freopen_s(&f, "CONOUT$", "w", stdout);
        freopen_s(&f, "CONERR$", "w", stderr);
        SetConsoleTitleA("CS2_Neverlose_Menu");
#endif
        CloseHandle(CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)(Setup), nullptr, NULL, nullptr));
    }
    else if (ul_reason_for_call == DLL_PROCESS_DETACH) {
        Blur::Shutdown();
    }
    return TRUE;
}

